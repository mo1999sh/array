package de.tukl.programmierpraktikum2020.mp1;

public class ListMap<K, V> implements Map<K, V>{

    ListenElems<K,V> head = new ListenElems<>(null, null);
    //ListenElems<K, V> safe = new ListenElems<>(null, null); Unnötig, Für existBefore

    
    public boolean isEmpty(){
        ListenElems<K,V> help = head;
        if (head == null || head.keys == null && head.values == null){
            return true;
        }else {return false;}
    }
    /*public boolean existBefore (K key) {
        ListenElems<K, V> help = head;
        boolean gefu = false;
        while (help.next != null) {
            if (help.keys.equals(key)) {
                help = safe;
                gefu = true;
            } else {
                help = help.next;
            }
        }return gefu;
    }*/


    @Override
    public V get(K key) {
        V rueckgabe = null;
        ListenElems<K, V> help = head;
        if (!isEmpty()) {
            while (help.next != null) {
                if (help.keys.equals(key)) {
                    rueckgabe = help.values;
                    break;
                } else {
                    help = help.next;
                }
            }
            if (help.keys.equals(key)) {
                rueckgabe = help.values;
            }
        }return rueckgabe;
    }

    @Override
    public void put(K key, V value) {
        ListenElems<K, V> h = head;
        ListenElems<K, V> neu = new ListenElems<>(key, value);
        if (isEmpty()) { //Leere Liste
            head = neu;
        } else {
            while (h.next != null) {
                if (h.keys == key) {
                    h.values = value;
                    break;
                }
                else {h = h.next;}
            }
                if (h.keys == key) {
                    h.values = value;
                }

                else {
                    h.next = neu; //hinten anhängen
                }
        }
    }


    @Override
    public void remove(K key) {
        if (!isEmpty()){
            ListenElems<K,V> help = head;
            if (head.keys.equals(key) && help.next != null){
                head = help.next;
            }else if (head.keys.equals(key) && help.next == null){
                head.keys = null; head.values = null;
            }
            else{
                while (help.next != null && !help.next.keys.equals(key)){
                    help = help.next;
                }
                if (help.next != null) {
                    help.next = help.next.next;
                }
            }
        }
    }


    @Override
    public int size() {
        int counter = 1;
        ListenElems<K, V> help = head;
        if (isEmpty()) {
            return 0;
        } else {
            while (help.next != null) {
                help = help.next;
                counter++;
            }
            return counter;
        }
    }

    @Override
    public void keys(K [] array) {
        if (array == null){
            throw new IllegalArgumentException();
        }
        ListenElems<K, V> help = head;
        try {

            for (int i= 0; i <= this.size()-1; i++){
                array[i] = help.keys; //NullPointer
                help = help.next;
                }
            }catch (ArrayIndexOutOfBoundsException e)
        {
            throw new IllegalArgumentException();
        }
    }
}

///Zum testen Main methode

class Main {
    public static void main(String[] args) {
        ListMap<String, Integer> neues = new ListMap<>();
        neues.put("gejesfo", 4);
        //System.out.print(neues.head.keys);
        // neues.put("dfgon", 5);
        neues.put("fgdj", 6);
        neues.put("fshei", 4);
         neues.put("hdsfhu", 2);
        neues.put("hdsfhu", 5);
        //System.out.println (neues.size());
        //neues.remove("hewksdvl"); //remove des ersten elems hat nicht geklappt
        //System.out.println(neues.size());
        //System.out.println(neues.getFirstKey());
        //System.out.println(neues.get("gejesfo"));
        //System.out.println(neues.get("fgdj"));
        //System.out.println (safe.values);
        //for (int i= 0; i < neues.size(); i++){
        //    System.out.println(neues.(i));
        String[] arrayx = new String[neues.size() + 10];
        neues.keys(arrayx);
        for (int i = 0; i < (arrayx).length; i++) {
            System.out.println(arrayx[i]);
        }
    }
}

//Problem: Wenn remove etwas entfernt und danach ist die Liste leer

