package de.tukl.programmierpraktikum2020.mp1;

import java.util.Comparator;

public class BibleAnalyzer {
    public static void countWords(Map<String, Integer> counts) {

        for (String word : Util. getBibleWords ()) {


            Integer krempel;

            krempel= counts.get(word);
            if (krempel == null) {
                counts.put(word, 1);
            } else {
                counts.put(word, krempel + 1);
            }

        }
    }

    public static void main(String[] args) {

        TreeMap<String, Integer> Bibelmap = new TreeMap<>(Comparator.<String>naturalOrder());
        //System.out.println("initialisiert");
        countWords(Bibelmap);
        //System.out.println("bibel gezählt");
        int size = Bibelmap.size();
        String[] words = new String[size];
        Bibelmap.keys(words);
        //System.out.println("bibel im array");
        sort(words, Bibelmap);
        //System.out.println("bibel sortiert");
        for (int i = 0; i < size; i++) {
            System.out.println(Bibelmap.get(words[i]) + " " + words[i]);
        }

    }

    public static void sort(String[] words, Map<String, Integer> counts) {
        // Bubblesort, vgl Algodat SS20, Blatt 2, Aufgabe 2.1. Laufzeit O(n^2)
        int n = words.length ;
         for (int i=0; i <= n -1; i++){
             for (int j=n -1; j >= i+1; j--){
                 if (counts.get(words[j-1]) > counts.get(words[j])){
                     String tmp = words[j-1];
                     words[j -1] = words[j];
                     words[j] = tmp;
                   }
                 }
            }

    }
}
