package de.tukl.programmierpraktikum2020.mp1;

import java.util.Comparator;

public class TreeMap<K, V> implements Map<K, V> {
    Node<K, V> tree;

    java.util.Comparator<K> c;

    TreeMap(java.util.Comparator<K> c) {
        this.tree = new Node<>(null, null, null, null, c);
        this.c = c;
    }

    @Override
    public V get(K key) {
        if (key != null) {
            return tree.find(tree, key);
        }
        return null;
    }

    @Override
    public void put(K key, V value) {
        //if (key != null) {
        //    tree = tree.insert(key, value);
        //}
        String e = "";
        try{
            if (key != null) {
                e = "noch nichts passiert";
                if (tree == null) {
                    e = "tree == null";
                    tree = new Node<>(null, null, key, value, c);
                } else if (tree.key == null) {
                    e = "tree.key == null";
                    tree.key = key;
                    tree.value = value;
                } else {
                    e = "else-Beginn";
                    int comp = c.compare(key, tree.key);
                    e = "Comp: " + comp;
                    if (comp == 0) {
                        tree.value = value;
                    } else if (comp < 0) {
                        if (tree.left == null) {
                            tree.left = new Node<>(null, null, key, value, c);
                        } else {
                            tree.left.insert(tree.left, key, value);
                        }
                    } else /*(comp > 0)*/ {
                        if (tree.right == null) {
                            tree.right = new Node<>(null, null, key, value, c);
                        } else {
                            tree.right.insert(tree.right, key, value);
                        }
                    }
                }
            }
        } catch (NullPointerException n) {
            System.out.println("Nullpointer in put; an der Stelle " + e);
        }
    }

    @Override
    public void remove(K key) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int size() {
        //return tree.size();
        try{
            if (tree == null || tree.key == null) {
                return 0;
            } else {
                TreeMap<K,V> l = new TreeMap<>(c);
                l.tree = tree.left;
                TreeMap<K,V> r = new TreeMap<>(c);
                r.tree = tree.right;

                return 1 + l.size() + r.size();
            }
        } catch (NullPointerException n) {
            System.out.println("Nullpointer in treesize; Key: " + tree.key);
        }
        return 0;
    }

    public K[] helperArray;
    int count;

    @Override
    public void keys(K[] array) {
        if (array == null || array.length < size()) {
            throw new IllegalArgumentException();
        } else {
            helperArray = array;
        }
        tree.getKeys(tree, size(), 0, array);
        //count = 0;
        //helper();
        //array = helperArray;
        //count = 0;
    }
    private void helper() {
        if (tree == null || tree.key == null) {
            // do nothing
        } else {
            helperArray[count] = tree.key;
            count++;

            TreeMap<K,V> l = new TreeMap<>(c);
            l.tree = tree.left;
            l.helper();

            TreeMap<K,V> r = new TreeMap<>(c);
            r.tree = tree.right;
            r.helper();
        }
    }


}
