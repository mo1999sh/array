package de.tukl.programmierpraktikum2020.mp1;

public class ListenElems<K,V> {
    public K keys;
    public V values;
    public ListenElems next;

    public ListenElems(K k, V v){
        this.keys = k;
        this.values = v;
        //next = null;
    }
}
