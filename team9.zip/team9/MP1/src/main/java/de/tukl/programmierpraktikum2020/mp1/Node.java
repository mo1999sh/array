package de.tukl.programmierpraktikum2020.mp1;

public class Node<K, V> {

    Node<K, V> left;
    Node<K, V> right;
    K key;
    V value;

    java.util.Comparator<K> c;

    Node(Node<K, V> l, Node<K, V> r, K k, V v, java.util.Comparator<K> c) {
        this.left = l;
        this.right = r;
        this.key = k;
        this.value = v;
        this.c = c;
    }
    /*String e = "";
    int size(Node<K, V> node) {
        e = e + "Start " + count + "; ";
        try{
            if (node == null) {
                e = e + "node == null; ";
                return 0;
            } else if (key == null) {
                e = e + "key == null; ";
                return 0;
            } else {
                e = e + "+1; Left.size: ";
                count++;
                return 1 + left.size(left) + right.size(right);
            }
        } catch (NullPointerException n) {
            System.out.println("Nullpointer in Node.size; Key: " + key + " an der Stelle: " + e);
        }
        return 0;
    }*/
    V find(Node<K, V> node, K fkey) {
        String e;
        if (node == null) {
            return null;
        } else if (fkey != null && key != null){
            e = " fkey und key != null.";
            try {
                int comp = c.compare(fkey, key);
                e = e + ", comp = " + comp;
                if(comp == 0) {
                    return value;
                } else if (comp < 0) {
                    if (node.left == null) {
                        return null;
                    } else {
                        return left.find(left, fkey);
                    }
                } else /*(comp > 0)*/ {
                    if (node.right == null) {
                        return null;
                    } else {
                        return right.find(right, fkey);
                    }
                }
            } catch (NullPointerException n) {
                System.out.println("Nullpointer in find; Fkey: " + fkey + " Key: " + key + ". An der Stelle: " + e);
            }
        }
        return null;
    }

    void insert(Node<K, V> node,K fkey, V fvalue) {
        String e = "";
        try{
            if (node == null) {
                e = "node == null";
                node = new Node<>(null, null, fkey, fvalue, c);
            } else if (node.key == null) {
                e = "node.key == null";
                node.key = fkey;
                node.value = value;
            } else {
                e = "else-Beginn, node.key: " + node.key + " node.value: " + node.value + " fkey: " + fkey;
                int comp = c.compare(fkey, node.key);
                e = "Comp: " + comp;
                if (comp == 0) { // Schlüssel bereits vorhanden
                    node.value = fvalue;
                } else if (comp < 0) { //fkey muss sich im linken Teilbaum befinden
                    if (node.left == null) {
                        node.left = new Node<>(null, null, fkey, fvalue, c);
                    } else {
                        node.left.insert(node.left, fkey, fvalue);
                    }
                } else /*(comp > 0)*/ { //fkey muss sich im rechten Teilbaum befinden
                    if (node.right == null) {
                        node.right = new Node<>(null, null, fkey, fvalue, c);
                    } else {
                        node.right.insert(node.right, fkey, fvalue);
                    }
                }
            }
        } catch (NullPointerException n) {
            System.out.println("Nullpointer in insert; an der Stelle " + e);
        }
    }


    void getKeys(Node<K, V> node, int size, int index, K[] keyArray) {
        //help(node, size, index, keyArray);
        if (index < size) {
            if (node == null) {
                // do nothing
            } else {
                keyArray[index] = key;

                if (left == null && right == null) {
                    // do nothing
                } else if (left == null && right != null) {
                    right.getKeys(right, size, index + 1, keyArray);
                } else if (left != null && right == null){
                    left.getKeys(left, size, index + 1, keyArray);
                } else {
                    left.getKeys(left, size, index + 1, keyArray);
                    TreeMap<K,V> l = new TreeMap<>(c);
                    l.tree = left;
                    right.getKeys(right, size, index + 1 + l.size(), keyArray);
                }
            }
        }
    }

/*
    private void help(Node<K, V> node, int size, int index, K[] keyArray) {
        while(index < size) {
            if (node == null || key == null) {
                break;
            } else {
                keyArray[index] = key;
                //i++;
                //TreeMap<K, V> l = new TreeMap<>(c);
                //l.tree = left;
                //System.out.println(keyArray);
                if (left == null){
                    return;
                } else {
                    left.help(left, size, index + 1, keyArray);
                }

            }
        } while(index < size) {
            if (node == null || key == null) {
                break;
            } else {
                keyArray[index] = key;
                //i++;
                TreeMap<K,V> l = new TreeMap<>(c);
                l.tree = left;
                System.out.println(keyArray);
                //left.help(left, size, index + 1, keyArray);
                if (right == null){
                    return;
                } else {
                    right.help(right, size, index + l.size() + 1, keyArray);
                }
            }
        }
    }

*/
}
