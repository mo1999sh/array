Programmierpraktikum SS20 - Team 9
==================================

Team
----

- Alisa Orschiedt <a_orschied19@cs.uni-kl.de>
- Anna Puttkammer <annasophie.puttkammer@online.de>
- Dominik Thoene <thoene@rhrk.uni-kl.de>
- Malak Al Sharoaa <m_al19@cs.uni-kl.de>


Betreuung
---------

- Tutor: Christopher
- Zeitslot für Abnahmen: wird noch bekannt gegeben
